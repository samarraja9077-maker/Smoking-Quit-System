# Smoking Quit System — Android project

A native Kotlin + Jetpack Compose Android starter app for a bilingual smoking-cessation companion.

## Included in version 1.0
- First-run setup: cigarettes per day, pack price, pack size, quit approach, language.
- Dark + green dashboard with quit-journey timer, estimated cigarettes avoided and estimated money saved.
- Immediate-quit and gradual-reduction approaches.
- Craving SOS screen with a two-minute reset timer, breathing and distraction suggestions.
- Motivational quote collection.
- Progress screen with general health-recovery education.
- Five daily local reminders (8 AM, 11 AM, 2 PM, 5 PM, 8 PM), with notification permission request.
- Local preferences storage; no account or server required.

## Build an APK in Android Studio
1. Extract this ZIP to a simple path such as `C:\AndroidProjects\SmokingQuitSystem` (avoid spaces in the folder path).
2. In Android Studio, create a new **Empty Activity** project using Kotlin + Jetpack Compose. Set the project name to `SmokingQuitSystem`, package to `com.smokingquitsystem.app`, and minimum SDK to API 26. Let Android Studio finish creating the project; this generates the Gradle wrapper files for your installation.
3. Close the newly created project. Copy the `app` folder and the `build.gradle.kts` and `settings.gradle.kts` files from this ZIP into the newly created project, replacing files when asked. **Keep** the generated `gradlew`, `gradlew.bat`, and `gradle/wrapper` files from Android Studio.
4. Reopen the generated project in Android Studio and allow Gradle sync. If prompted, install Android SDK Platform 35 and accept the Android Gradle Plugin / Gradle downloads.
5. If Android Studio asks for a Gradle JDK, select the bundled JDK 17 or another JDK 17.
6. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. When the build succeeds, click **locate** in the notification. The APK is normally at `app\build\outputs\apk\debug\app-debug.apk`.
8. Transfer that APK to your Android phone and install it. Allow “Install unknown apps” for the file manager/browser if Android asks.

You do not need to start an Android emulator to build the APK. The emulator can be skipped; it is optional for testing.

## Important notes
- This workspace did not have the Android SDK or Gradle installed, so an APK could not be compiled in this environment. The complete Android Studio source project is supplied instead.
- The five reminder times are currently fixed at 8 AM, 11 AM, 2 PM, 5 PM and 8 PM. Android may delay inexact alarms to conserve battery.
- The gradual-reduction target is a suggested educational plan (20% reduction per week), not a prescribed medical treatment. The user can change approach in Settings.
- Cigarettes avoided and money saved are estimates calculated from the onboarding information; they are not based on individually logged cigarettes.
- Health milestones are general educational information and not a personal medical prediction. The app is not a substitute for medical advice or evidence-based cessation support.
- For production release, add app branding/assets, QA on multiple Android versions, accessibility checks, privacy policy, and a signed release build.
