package com.smokingquitsystem.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private val Bg = Color(0xFF08130F)
private val Panel = Color(0xFF12231B)
private val Green = Color(0xFF35D07F)
private val Soft = Color(0xFF9FB7A9)
private val White = Color(0xFFF2F7F3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        setContent { SmokingQuitApp(this) }
    }
}

private fun prefs(c: Context) = c.getSharedPreferences("quit_system", Context.MODE_PRIVATE)
private fun createNotificationChannel(c: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val channel = NotificationChannel("quit_reminders", "Quit reminders", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Daily encouragement to stay smoke-free"
        }
        c.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}

fun scheduleReminders(c: Context) {
    val p = prefs(c)
    if (!p.getBoolean("reminders", true)) return
    val alarm = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val hours = intArrayOf(8, 11, 14, 17, 20)
    hours.forEachIndexed { i, hour ->
        val intent = Intent(c, ReminderReceiver::class.java).putExtra("slot", i)
        val pi = PendingIntent.getBroadcast(c, 5100 + i, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, hour); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR, 1)
        }
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
    }
}

class ReminderReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val slot = intent.getIntExtra("slot", 0)
        val roman = prefs(context).getString("language", "Both") != "English"
        val messages = if (roman) listOf(
            "Aaj ka din smoke-free rakhein. Aap kar sakte hain! 💚",
            "Craving temporary hai. Gehri saans lein aur 5 minute rukain.",
            "Har cigarette se door rehna aapki jeet hai.",
            "Apni wajah yaad karein. Aapki sehat qeemti hai.",
            "Aaj ki progress par fakhar karein. Kal se behtar aaj banayein!"
        ) else listOf(
            "Keep today smoke-free. You've got this! 💚",
            "A craving is temporary. Breathe deeply and wait five minutes.",
            "Every cigarette avoided is a win.",
            "Remember your reason. Your health matters.",
            "Be proud of today's progress. Keep going!"
        )
        val n = NotificationCompat.Builder(context, "quit_reminders")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Smoking Quit System")
            .setContentText(messages[slot.coerceIn(0, 4)])
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true).build()
        if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
            NotificationManagerCompat.from(context).notify(700 + slot, n)
        }
    }
}

class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) { scheduleReminders(context) }
}

@Composable
fun SmokingQuitApp(context: Context) {
    val p = remember { prefs(context) }
    var configured by remember { mutableStateOf(p.getBoolean("configured", false)) }
    var page by remember { mutableStateOf("Home") }
    var language by remember { mutableStateOf(p.getString("language", "Both") ?: "Both") }
    var refresh by remember { mutableIntStateOf(0) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    MaterialTheme(colorScheme = darkColorScheme(primary = Green, background = Bg, surface = Panel, onBackground = White, onSurface = White)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            if (!configured) {
                SetupScreen(context, language) { daily, price, pack, method, lang ->
                    p.edit().putBoolean("configured", true).putLong("quit_start", System.currentTimeMillis())
                        .putInt("cigs_day", daily).putFloat("pack_price", price).putInt("pack_size", pack)
                        .putString("method", method).putString("active_mode", if (method == "Gradual reduction") "Gradual reduction" else "Quit immediately").putString("language", lang).putBoolean("reminders", true).apply()
                    language = lang; configured = true
                    if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                    scheduleReminders(context)
                }
            } else {
                Column(Modifier.fillMaxSize()) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("SMOKING QUIT SYSTEM", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                            Text(pageTitle(page, language), color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                            Text("By Jawad", color = Soft, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        }
                        Box(Modifier.size(42.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Eco, null, tint = Green) }
                    }
                    Box(Modifier.weight(1f)) {
                        when (page) {
                            "Home" -> HomeScreen(p, language, refresh)
                            "Progress" -> ProgressScreen(p, language, refresh)
                            "SOS" -> SosScreen(language)
                            "Quotes" -> QuotesScreen(language)
                            else -> SettingsScreen(context, p, language) { newLang -> language = newLang; refresh++ }
                        }
                    }
                    NavigationBar(containerColor = Panel, contentColor = Green) {
                        listOf(Triple("Home", Icons.Default.Home, "Home"), Triple("Progress", Icons.Default.Insights, "Progress"), Triple("SOS", Icons.Default.Favorite, "SOS"), Triple("Quotes", Icons.Default.FormatQuote, "Quotes"), Triple("Settings", Icons.Default.Settings, "Settings")).forEach { (label, icon, key) ->
                            NavigationBarItem(selected = page == key, onClick = { page = key }, icon = { Icon(icon, null) }, label = { Text(tr(language, label, navRoman(label)), fontSize = 10.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Green, selectedTextColor = Green, indicatorColor = Color(0xFF244B36), unselectedIconColor = Soft, unselectedTextColor = Soft))
                        }
                    }
                }
            }
        }
    }
}

private fun tr(lang: String, english: String, roman: String): String = when (lang) { "English" -> english; "Roman Urdu" -> roman; else -> "$english / $roman" }

private fun pageTitle(page: String, lang: String): String = tr(lang, page, when(page) { "Home"->"Aapki progress"; "Progress"->"Taraqqi"; "SOS"->"Craving SOS"; "Quotes"->"Honsla afzai"; else->"Settings" })
private fun navRoman(s: String) = when(s) { "Home"->"Home"; "Progress"->"Progress"; "SOS"->"SOS"; "Quotes"->"Quotes"; else->"Settings" }

@Composable
fun SetupScreen(context: Context, initialLang: String, onDone: (Int, Float, Int, String, String) -> Unit) {
    var daily by remember { mutableStateOf("10") }
    var price by remember { mutableStateOf("500") }
    var pack by remember { mutableStateOf("20") }
    var method by remember { mutableStateOf("Both") }
    var lang by remember { mutableStateOf(initialLang) }
    LazyColumn(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Spacer(Modifier.height(12.dp)); Text("🚭", fontSize = 42.sp)
            Text("Smoking Quit System", color = Green, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text("By Jawad", color = Soft, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text("Your fresh start begins here", color = White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Aapka naya safar yahan se shuru hota hai. No judgement, just progress.", color = Soft, fontSize = 14.sp)
        }
        item { Field("Cigarettes per day / Roz kitni cigarettes?", daily) { daily = it } }
        item { Field("Price per pack (PKR) / Packet ki qeemat", price) { price = it } }
        item { Field("Cigarettes in one pack / Packet mein cigarettes", pack) { pack = it } }
        item {
            Text("Choose your quit approach / Quit karne ka tareeqa", color = White, fontWeight = FontWeight.SemiBold)
            listOf("Both", "Gradual reduction", "Quit immediately").forEach { v -> ChoiceRow(v, method == v) { method = v } }
        }
        item {
            Text("App language", color = White, fontWeight = FontWeight.SemiBold)
            listOf("Both", "English", "Roman Urdu").forEach { v -> ChoiceRow(v, lang == v) { lang = v } }
        }
        item {
            Button(onClick = { onDone(daily.toIntOrNull()?.coerceIn(1, 100) ?: 10, price.toFloatOrNull()?.coerceAtLeast(0f) ?: 500f, pack.toIntOrNull()?.coerceIn(1, 100) ?: 20, method, lang) }, modifier = Modifier.fillMaxWidth().height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg), shape = RoundedCornerShape(16.dp)) { Text("Start my smoke-free journey  →", fontWeight = FontWeight.Bold) }
            Text("You can change these details anytime in Settings.", color = Soft, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
        }
    }
}

@Composable fun Field(label: String, value: String, onChange: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(label, color = White, fontWeight = FontWeight.Medium, fontSize = 13.sp)
        OutlinedTextField(value, onChange, modifier = Modifier.fillMaxWidth(), singleLine = true, shape = RoundedCornerShape(13.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Green, unfocusedBorderColor = Color(0xFF345143), focusedTextColor = White, unfocusedTextColor = White))
    }
}
@Composable fun ChoiceRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).background(if(selected) Color(0xFF1B3B2A) else Panel, RoundedCornerShape(12.dp)).clickable { onClick() }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(selected, onClick, colors = RadioButtonDefaults.colors(selectedColor = Green, unselectedColor = Soft)); Text(label, color = White, modifier = Modifier.padding(start = 8.dp))
    }
}

private fun elapsed(p: android.content.SharedPreferences): Long = max(0L, System.currentTimeMillis() - p.getLong("quit_start", System.currentTimeMillis()))
private fun days(p: android.content.SharedPreferences) = elapsed(p) / 86_400_000L
private fun cigsSaved(p: android.content.SharedPreferences): Int {
    val totalDays = (elapsed(p) / 86_400_000L).toInt()
    val base = p.getInt("cigs_day", 10)
    val gradual = p.getString("active_mode", "Quit immediately") == "Gradual reduction"
    if (!gradual) return totalDays * base
    return (0 until totalDays).sumOf { day ->
        val reduction = ((day / 7) * 0.20).coerceIn(0.0, 1.0)
        (base * reduction).toInt()
    }
}
private fun moneySaved(p: android.content.SharedPreferences): Int {
    val pack = p.getInt("pack_size", 20).coerceAtLeast(1)
    return (cigsSaved(p) * (p.getFloat("pack_price", 500f) / pack)).toInt()
}
private fun duration(p: android.content.SharedPreferences): String {
    val ms = elapsed(p); val d = ms / 86_400_000; val h = (ms / 3_600_000) % 24; val m = (ms / 60_000) % 60
    return "${d}d  ${h}h  ${m}m"
}

@Composable fun HomeScreen(p: android.content.SharedPreferences, lang: String, refresh: Int) {
    val day = days(p); val cigs = cigsSaved(p); val money = moneySaved(p)
    val title = tr(lang, "Your smoke-free journey", "Aapka smoke-free safar")
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(title, color = Soft, fontSize = 13.sp)
                    Text("${day}", color = Green, fontSize = 64.sp, fontWeight = FontWeight.ExtraBold)
                    Text(tr(lang, "DAYS ON QUIT JOURNEY", "QUIT JOURNEY KE DIN"), color = White, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text(duration(p), color = Soft, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                    Text(tr(lang, "One moment at a time. Keep going.", "Bas aik lamha aik waqt mein. Aagay barhtay rahain."), color = Green, fontSize = 13.sp, modifier = Modifier.padding(top = 12.dp))
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("$cigs", tr(lang, "Cigarettes avoided", "Cigarettes se bachay"), Icons.Default.Block, Modifier.weight(1f))
            StatCard("Rs ${money}", tr(lang, "Estimated saved", "Andazan bachay"), Icons.Default.Savings, Modifier.weight(1f))
        } }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF173626)), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(17.dp)) {
                    Text(tr(lang, "TODAY'S REMINDER", "AAJ KI YAAD DEHANI"), color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(tr(lang, "A craving is a wave. You don't have to act on it. Pause, breathe, and let it pass.", "Craving aik lehar ki tarah hai. Is par amal zaroori nahi. Rukain, saans lein aur guzarne dein."), color = White, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        item { Text(tr(lang, "Your next small win", "Aapki agli choti jeet"), color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item {
            val mode = p.getString("active_mode", "Quit immediately") ?: "Quit immediately"
            val base = p.getInt("cigs_day", 10)
            val week = (day / 7).toInt()
            val target = if (mode == "Gradual reduction") max(0, (base * (1.0 - (week * 0.20))).toInt()) else 0
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(tr(lang, "YOUR CURRENT APPROACH", "AAPKA MAUJOODA TAREEQA"), color = Green, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text(if(mode == "Gradual reduction") tr(lang, "Gradual reduction", "Aahista aahista kami") else tr(lang, "Quit immediately", "Foran quit"), color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                    if(mode == "Gradual reduction") Text(tr(lang, "Suggested target: about $target cigarettes/day (from $base). Adjust with a healthcare professional if needed.", "Tajweez shuda target: taqreeban $target cigarettes rozana (pehle $base). Zaroorat par healthcare professional se mashwara karein."), color = Soft, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    else Text(tr(lang, "Focus on staying smoke-free, one craving at a time.", "Har craving ka aik aik kar ke muqabla karein aur smoking se door rahain."), color = Soft, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
        item { MilestoneCard(lang) }
    }
}

@Composable fun StatCard(value: String, label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp)) { Icon(icon, null, tint = Green); Text(value, color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)); Text(label, color = Soft, fontSize = 11.sp) }
    }
}
@Composable fun MilestoneCard(lang: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(tr(lang, "A helpful health fact", "Sehat ki aik maloomat"), color = Green, fontWeight = FontWeight.Bold)
            Text(tr(lang, "Within about 20 minutes after your last cigarette, heart rate and blood pressure can begin moving toward normal. Recovery timelines vary from person to person.", "Aakhri cigarette ke taqreeban 20 minute baad dil ki dharkan aur blood pressure normal ki taraf aana shuru ho sakte hain. Har shakhs ki recovery mukhtalif hoti hai."), color = White, fontSize = 13.sp, modifier = Modifier.padding(top = 7.dp))
        }
    }
}

@Composable fun ProgressScreen(p: android.content.SharedPreferences, lang: String, refresh: Int) {
    val day = days(p); val cigs = cigsSaved(p); val saved = moneySaved(p)
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { Text(tr(lang, "Your progress", "Aapki taraqqi"), color = White, fontSize = 23.sp, fontWeight = FontWeight.Bold) }
        item { StatCard(duration(p), tr(lang, "Time since your quit start", "Quit shuru kiye hue"), Icons.Default.Timer, Modifier.fillMaxWidth()) }
        item { StatCard("$cigs", tr(lang, "Estimated cigarettes avoided", "Andazan cigarettes se bachay"), Icons.Default.Block, Modifier.fillMaxWidth()) }
        item { StatCard("PKR $saved", tr(lang, "Estimated money saved", "Andazan paisay bachay"), Icons.Default.Savings, Modifier.fillMaxWidth()) }
        item { Text(tr(lang, "Recovery milestones", "Sehat ke marahil"), color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp) }
        listOf("20 minutes" to "Heart rate and blood pressure may begin to improve.", "12 hours" to "Carbon monoxide level in blood can return toward normal.", "2–12 weeks" to "Circulation and lung function may improve.", "1–9 months" to "Coughing and shortness of breath may decrease.").forEach { (t, d) -> item { Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CheckCircle, null, tint = if(day>0) Green else Soft); Column(Modifier.padding(start = 12.dp)) { Text(t, color = White, fontWeight = FontWeight.Bold); Text(d, color = Soft, fontSize = 12.sp) } } } } }
        item { Text(tr(lang, "Milestones are general educational estimates, not a personal medical prediction.", "Yeh aam maloomati andazay hain, zaati medical prediction nahi."), color = Soft, fontSize = 11.sp) }
    }
}

@Composable fun SosScreen(lang: String) {
    var seconds by remember { mutableIntStateOf(120) }
    var running by remember { mutableStateOf(false) }
    LaunchedEffect(running, seconds) { if(running && seconds>0) { kotlinx.coroutines.delay(1000); seconds--; if(seconds==0) running=false } }
    Column(Modifier.fillMaxSize().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("🫁", fontSize = 48.sp)
        Text(tr(lang, "Craving SOS", "Craving ka muqabla"), color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text(tr(lang, "The urge will pass. Give yourself two minutes.", "Yeh talab guzar jayegi. Khud ko do minute dein."), color = Soft, textAlign = TextAlign.Center)
        Box(Modifier.size(210.dp).background(Panel, CircleShape), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("${seconds/60}:${(seconds%60).toString().padStart(2,'0')}", color = Green, fontSize = 48.sp, fontWeight = FontWeight.Bold); Text(if(running) "BREATHE" else "PAUSE", color = Soft, fontSize = 12.sp) }
        }
        Button(onClick = { if(seconds==0) seconds=120; running=!running }, colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg), modifier = Modifier.fillMaxWidth()) { Text(if(running) "Pause timer" else if(seconds==0) "Start again" else "Start 2-minute reset") }
        OutlinedButton(onClick = { seconds=120; running=false }, modifier = Modifier.fillMaxWidth()) { Text("Reset") }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text(tr(lang, "Try this now", "Abhi yeh karein"), color = Green, fontWeight = FontWeight.Bold)
                listOf(tr(lang, "Take 5 slow breaths.", "5 aahista saans lein."), tr(lang, "Drink a glass of water.", "Aik glass pani piyen."), tr(lang, "Move away from your smoking trigger.", "Smoking wali jagah ya trigger se door ho jayein."), tr(lang, "Message someone who supports you.", "Kisi supportive dost ya ghar walay ko message karein.")).forEach { Text("• $it", color = White, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)) }
            }
        }
        Text(tr(lang, "If withdrawal feels overwhelming, a healthcare professional can help you choose evidence-based support.", "Agar withdrawal mushkil ho, healthcare professional se evidence-based madad lein."), color = Soft, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

@Composable fun QuotesScreen(lang: String) {
    val english = listOf("You are stronger than a temporary craving.", "Don't count the days. Make the days count.", "Every cigarette you skip is a choice for your future.", "A slip is not the end. Learn, reset, continue.", "You deserve a life that isn't controlled by nicotine.", "Small wins become a powerful new habit.")
    val roman = listOf("Aap aik aarzi craving se zyada mazboot hain.", "Sirf din na ginein, har din ko qeemti banayein.", "Har chori hui cigarette aapke mustaqbil ke haq mein faisla hai.", "Aik slip ka matlab haar nahi. Seekhein, dobara shuru karein.", "Aap aisi zindagi deserve karte hain jo nicotine ke qaboo mein na ho.", "Choti jeetain mil kar bari kamyabi banti hain.")
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text(tr(lang, "A little motivation", "Thora sa hosla"), color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        items(english.size) { i -> Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.Top) { Text("“", color = Green, fontSize = 34.sp, fontWeight = FontWeight.Bold); Text(tr(lang, english[i], roman[i]), color = White, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 8.dp, top = 7.dp)) } } }
    }
}

@Composable fun SettingsScreen(context: Context, p: android.content.SharedPreferences, current: String, onLanguage: (String)->Unit) {
    var reminders by remember { mutableStateOf(p.getBoolean("reminders", true)) }
    var lang by remember { mutableStateOf(current) }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Preferences", color = White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item { Text("Language / Zubaan", color = Soft); listOf("Both", "English", "Roman Urdu").forEach { ChoiceRow(it, lang==it) { lang=it; p.edit().putString("language",it).apply(); onLanguage(it) } } }
        item { Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { Text("Daily reminders", color = White, fontWeight = FontWeight.Bold); Text("5 reminders: 8 AM, 11 AM, 2 PM, 5 PM, 8 PM", color = Soft, fontSize = 11.sp) }; Switch(reminders, { reminders=it; p.edit().putBoolean("reminders",it).apply(); if(it) scheduleReminders(context) else { val am=context.getSystemService(Context.ALARM_SERVICE) as AlarmManager; repeat(5) { i -> val pi=PendingIntent.getBroadcast(context,5100+i,Intent(context,ReminderReceiver::class.java),PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); am.cancel(pi) } } }, colors = SwitchDefaults.colors(checkedThumbColor = Green)) } } }
        item { Text("Your quit plan / Aapka quit plan", color = Green, fontWeight = FontWeight.Bold) }
        item { Text("Choose your current approach", color = White, fontWeight = FontWeight.SemiBold) }
        item { listOf("Quit immediately", "Gradual reduction").forEach { mode -> ChoiceRow(mode, (p.getString("active_mode", "Quit immediately") ?: "Quit immediately") == mode) { p.edit().putString("active_mode", mode).apply() } } }
        item { Text("Available options: ${p.getString("method", "Both")}", color = Soft, fontSize = 12.sp) }
        item { Text("Daily cigarettes before quitting: ${p.getInt("cigs_day",10)}", color = White) }
        item { Text("Pack price: PKR ${p.getFloat("pack_price",500f)}", color = White) }
        item { Text("Data is stored locally on this phone. Estimated savings and avoided cigarettes are based on the details you entered.", color = Soft, fontSize = 12.sp) }
        item { OutlinedButton(onClick = { p.edit().putBoolean("configured",false).apply() }, modifier = Modifier.fillMaxWidth()) { Text("Reset app setup") } }
    }
}
