# Build the APK in GitHub Actions (no Android Studio or emulator needed)

This repository includes `.github/workflows/android-apk.yml`. GitHub Actions builds a debug APK on a hosted Linux runner and attaches it as a downloadable workflow artifact.

1. Create a GitHub repository and upload the **contents** of the `SmokingQuitSystem` folder (including `.github`).
2. Open the repository's **Actions** tab.
3. Select **Build Smoking Quit System APK** and press **Run workflow** (or push to `main`).
4. Wait for the workflow to finish successfully.
5. Open the completed workflow run and download the artifact named `Smoking-Quit-System-By-Jawad-APK`.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`. Transfer that APK to the Android phone and install it.

The artifact is a debug APK for personal testing, not a Play Store release. Android may ask you to allow installation from the file manager/browser.
